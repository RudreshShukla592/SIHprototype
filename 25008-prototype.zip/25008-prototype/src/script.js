import * as THREE from 'three'
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js'
import { Sky } from 'three/addons/objects/Sky.js'
import { Timer } from 'three/addons/misc/Timer.js'
import { ThreeMFLoader } from 'three/examples/jsm/Addons.js'
import { gsap } from "gsap"




/**
 * Base
 */
// Debug
// const gui = new GUI()

// Canvas
const canvas = document.querySelector('canvas.webgl')

// Scene
const scene = new THREE.Scene()


/**
 * textures
 */
const textureloader = new THREE.TextureLoader()

// floor
const flooralphatexture = textureloader.load('./floor/alpha.jpg')
const floorcolortexture = textureloader.load('./floor/coast_sandrock1/coast_sand_rocks_02_diff_1k.jpg')
const floorarmtexture = textureloader.load('./floor/coast_sandrock1/coast_sand_rocks_02_arm_1k.jpg')
const floornormaltexture = textureloader.load('./floor/coast_sandrock1/coast_sand_rocks_02_nor_gl_1k.jpg')
const floordisplacementtexture = textureloader.load('./floor/coast_sandrock1/coast_sand_rocks_02_disp_1k.jpg')

floorcolortexture.colorSpace = THREE.SRGBColorSpace

floorcolortexture.repeat.set(8,8)
floorarmtexture.repeat.set(8,8)
floornormaltexture.repeat.set(8,8)
floordisplacementtexture.repeat.set(8,8)


floorcolortexture.wrapS = THREE.RepeatWrapping
floorarmtexture.wrapS = THREE.RepeatWrapping
floornormaltexture.wrapS = THREE.RepeatWrapping
floordisplacementtexture.wrapS = THREE.RepeatWrapping

floorcolortexture.wrapT = THREE.RepeatWrapping
floorarmtexture.wrapT = THREE.RepeatWrapping
floornormaltexture.wrapT = THREE.RepeatWrapping
floordisplacementtexture.wrapT = THREE.RepeatWrapping


// walls

const wallcolortexture = textureloader.load('./wall/castel_brick1/castle_brick_broken_06_diff_1k.jpg')
const wallarmtexture = textureloader.load('./wall/castel_brick1/castle_brick_broken_06_arm_1k.jpg')
const wallnormaltexture = textureloader.load('./wall/castel_brick1/castle_brick_broken_06_nor_gl_1k.jpg')

wallcolortexture.colorSpace = THREE.SRGBColorSpace

// roof
const roofcolortexture= textureloader.load('./roof/roof_slates/roof_slates_02_diff_1k.jpg')
const roofarmtexture= textureloader.load('./roof/roof_slates/roof_slates_02_arm_1k.jpg')
const roofnormaltexture= textureloader.load('./roof/roof_slates/roof_slates_02_nor_gl_1k.jpg')

roofcolortexture.colorSpace = THREE.SRGBColorSpace


roofcolortexture.repeat.set(3,1)
roofarmtexture.repeat.set(3,1)
roofnormaltexture.repeat.set(3,1)

roofcolortexture.wrapS = THREE.RepeatWrapping
roofarmtexture.wrapS = THREE.RepeatWrapping
roofnormaltexture.wrapS = THREE.RepeatWrapping

// bushes

const bushcolortexture = textureloader.load('./bushes/leaves/leaves_forest_ground_diff_1k.jpg')
const busharmtexture = textureloader.load('./bushes/leaves/leaves_forest_ground_arm_1k.jpg')
const bushnormaltexture = textureloader.load('./bushes/leaves/leaves_forest_ground_nor_gl_1k.jpg')
bushcolortexture.colorSpace = THREE.SRGBColorSpace

bushcolortexture.repeat.set(2,1)
busharmtexture.repeat.set(2,1)
bushnormaltexture.repeat.set(2,1)

bushcolortexture.wrapS = THREE.RepeatWrapping
busharmtexture.wrapS = THREE.RepeatWrapping
bushnormaltexture.wrapS = THREE.RepeatWrapping

// graves
const gravescolortexture = textureloader.load('./grave/stone/plastered_stone_wall_diff_1k.jpg')
const gravesarmtexture = textureloader.load('./grave/stone/plastered_stone_wall_arm_1k.jpg')
const gravesnormaltexture = textureloader.load('./grave/stone/plastered_stone_wall_nor_gl_1k.jpg')
gravescolortexture.colorSpace = THREE.SRGBColorSpace

gravescolortexture.repeat.set(0.3,0.4)
gravesarmtexture.repeat.set(0.3,0.4)
gravesnormaltexture.repeat.set(0.3,0.4)

// door

const doorColorTexture = textureloader.load('./door/color.jpg')
const doorAlphaTexture = textureloader.load('./door/alpha.jpg')
const doorAmbientOcclusionTexture = textureloader.load('./door/ambientOcclusion.jpg')
const doorHeightTexture = textureloader.load('./door/height.jpg')
const doorNormalTexture = textureloader.load('./door/normal.jpg')
const doorMetalnessTexture = textureloader.load('./door/metalness.jpg')
const doorRoughnessTexture = textureloader.load('./door/roughness.jpg')

doorColorTexture.colorSpace = THREE.SRGBColorSpace

/**
 * House
 */


// floor
const floor = new THREE.Mesh(
    new THREE.PlaneGeometry(20,20,100,100),
    new THREE.MeshStandardMaterial({
        alphaMap:flooralphatexture,
        transparent:true,
        map:floorcolortexture,
        aoMap:floorarmtexture,
        roughnessMap:floorarmtexture,
        metalnessMap:floorarmtexture,
        normalMap:floornormaltexture,
        displacementMap:floordisplacementtexture,
        displacementScale:0.3,
        displacementBias: -0.222
    })
)
floor.rotation.x = -(Math.PI * 0.5)
scene.add(floor);


const house = new THREE.Group();
scene.add(house)
 
// walls
const walls = new THREE.Mesh(
    new THREE.BoxGeometry(4,2.5,4),
    new THREE.MeshStandardMaterial({
        map:wallcolortexture,
        aoMap:wallarmtexture,
        roughnessMap:wallarmtexture,
        metalnessMap:wallarmtexture,
        normalMap:wallnormaltexture
    })
)
house.add(walls)
walls.position.y+=1.25

// roof
const roof = new THREE.Mesh(
    new THREE.ConeGeometry(3.5,1.5,4),
    new THREE.MeshStandardMaterial({
        map:roofcolortexture,
        aoMap:roofarmtexture,
        roughnessMap:roofarmtexture,
        metalnessMap:roofarmtexture,
        normalMap:roofnormaltexture
    })
)
house.add(roof)
roof.position.y = 2.5+0.75
roof.rotation.y = Math.PI * 0.25

// door
const door =  new THREE.Mesh(
    new THREE.PlaneGeometry(2.2,2.2,100,100),
    new THREE.MeshStandardMaterial({
        map: doorColorTexture,
        transparent: true,
        alphaMap: doorAlphaTexture,
        aoMap: doorAmbientOcclusionTexture,
        displacementMap: doorHeightTexture,
        displacementScale:0.15,
        displacementBias:-0.04,
        normalMap: doorNormalTexture,
        metalnessMap: doorMetalnessTexture,
        roughnessMap: doorRoughnessTexture

    })
)
door.position.y =1
door.position.z =2+0.01
house.add(door)

// bushes
const bushgeometry = new THREE.SphereGeometry(1,16,16)
const bushmaterial = new THREE.MeshStandardMaterial({
    color:'#ccffcc',
    map:bushcolortexture,
    aoMap:busharmtexture,
    roughnessMap:busharmtexture,
    metalnessMap:busharmtexture,
    normalMap:bushnormaltexture
})

const bush1 = new THREE.Mesh(bushgeometry,bushmaterial)
bush1.scale.set(0.5,0.5,0.5)
bush1.position.set(0.8,0.2,2.2)
bush1.rotation.x = -0.75
house.add(bush1)
const bush2 = new THREE.Mesh(bushgeometry,bushmaterial)
bush2.scale.set(0.25,0.25,0.25)
bush2.position.set(1.4,0.1,2.1)
bush2.rotation.x = -0.75
house.add(bush2)
const bush3 = new THREE.Mesh(bushgeometry,bushmaterial)
bush3.scale.set(0.4,0.4,0.4)
bush3.position.set(-0.8,0.1,2.2)
bush3.rotation.x = -0.75
house.add(bush3)
const bush4 = new THREE.Mesh(bushgeometry,bushmaterial)
bush4.scale.set(0.15,0.15,0.15)
bush4.position.set(-1,0.05,2.6)
bush4.rotation.x = -0.75
house.add(bush4)


// graves
const gravegeometry = new THREE.BoxGeometry(0.6,0.6,0.2)
const gravematerial = new THREE.MeshStandardMaterial({
        map:gravescolortexture,
        aoMap:gravesarmtexture,
        roughnessMap:gravesarmtexture,
        metalnessMap:gravesarmtexture,
        normalMap:gravesnormaltexture
});
const graves = new THREE.Group();
scene.add(graves)

for(let i =0 ;i<25;i++){
    const angle = Math.random() * Math.PI * 2
    const radius = 3 + (Math.random()*4)
    const x = Math.sin(angle)*radius
    const z = Math.cos(angle)*radius

    const grave = new THREE.Mesh(gravegeometry,gravematerial);
    grave.position.x=x
    grave.position.z=z
    grave.position.y = Math.random() * 0.3

    grave.rotation.x = (Math.random() - 0.5)*0.4
    grave.rotation.y = (Math.random() - 0.5)*0.4
    grave.rotation.z =( Math.random() - 0.5)*0.4
    graves.add(grave)
}
/**
 * Lights
 */
// Ambient light
const ambientLight = new THREE.AmbientLight('#86cdff', 0.275)
scene.add(ambientLight)

// Directional light
const directionalLight = new THREE.DirectionalLight('#86cdff', 1)
directionalLight.position.set(3, 2, -8)
scene.add(directionalLight)

// doorlight
const doorlight = new THREE.PointLight('#ff7d46',5)
doorlight.position.set(0,2.2,2.5)
scene.add(doorlight)

/**
 * Sizes
 */
const sizes = {
    width: window.innerWidth,
    height: window.innerHeight
}

window.addEventListener('resize', () =>
{
    // Update sizes
    sizes.width = window.innerWidth
    sizes.height = window.innerHeight

    // Update camera
    camera.aspect = sizes.width / sizes.height
    camera.updateProjectionMatrix()

    // Update renderer
    renderer.setSize(sizes.width, sizes.height)
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))
})

/**
 * Camera
 */
// Base camera
const camera = new THREE.PerspectiveCamera(75, sizes.width / sizes.height, 0.1, 100)
camera.position.x = 4
camera.position.y = 2
camera.position.z = 5
scene.add(camera)

// Controls
const controls = new OrbitControls(camera, canvas)
controls.enableDamping = true

/**
 * Renderer
 */
const renderer = new THREE.WebGLRenderer({
    canvas: canvas
})
renderer.setSize(sizes.width, sizes.height)
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2))

/**
 * SHADOWS
 */

// renderer
renderer.shadowMap.enabled = true
renderer.shadowMap.type = THREE.PCFSoftShadowMap

directionalLight.castShadow = true

walls.castShadow = true
roof.castShadow = true
floor.receiveShadow = true 

for(const grave of graves.children){
    grave.castShadow = true
    grave.receiveShadow = true
}

// mapping
directionalLight.shadow.mapSize.width = 256
directionalLight.shadow.mapSize.height = 256
directionalLight.shadow.camera.top = 8
directionalLight.shadow.camera.right = 8
directionalLight.shadow.camera.bottom = - 8
directionalLight.shadow.camera.left = - 8
directionalLight.shadow.camera.near = 1
directionalLight.shadow.camera.far = 20


/**
 * SKY
 */

const sky =  new Sky()
sky.scale.set(100,100,100)
scene.add(sky)

sky.material.uniforms['turbidity'].value = 10
sky.material.uniforms['rayleigh'].value = 3
sky.material.uniforms['mieCoefficient'].value = 0.1
sky.material.uniforms['mieDirectionalG'].value = 0.95
sky.material.uniforms['sunPosition'].value.set(0.3, -0.038, -0.95)

/**
 * FOD
 */

scene.fog = new THREE.FogExp2('#02343f',0.1)

/**
 * FULLSCREEN
 */

window.addEventListener("dblclick",()=>{
    if(!document.fullscreenElement){
        canvas.requestFullscreen()
    }else{
        document.exitFullscreen()
    }
})

const startScreen = document.getElementById("start-screen");
const startBtn = document.getElementById("start-btn");
const quizScreen = document.getElementById("quiz-screen");
const resultScreen = document.getElementById("result-screen");
const safeChoiceBtn = document.getElementById("safe-choice-btn");
const riskyChoiceBtn = document.getElementById("risky-choice-btn");
const resultMessage = document.getElementById("result-message");
const outcome = document.querySelector("#outcome")

const simulation = { state: "idle", shakeIntensity: 0 };


document.addEventListener('keydown',(event)=>{
    if(event.key === 'Enter'){
        startScreen.style.display = "block"
    }
})


startBtn.addEventListener("click", () => {
  gsap.to(startScreen, {
    opacity: 0,
    duration: 0.5,
    onComplete: () => {
      // Wait 2-3 seconds before starting the earthquake
      setTimeout(() => {
        simulation.state = "shaking"; // now applyShake() will trigger
        simulation.shakeIntensity = 1.0;
      }, 2000); // change 2000 → 3000 for 3s delay
    }
    })
  simulation.state = "shaking";
  gsap.to(simulation, { shakeIntensity: 1, duration: 1 });

  // Move camera inside house after delay (like POV)
  gsap.to(camera.position, {
    x: 0,     // center
    y: 1.5,     // eye height
    z: 1.8,   // move closer inside
    duration: 3,
    delay: 1.5, // wait for shaking to start
    onUpdate: () => {
      camera.lookAt(0, 1, 0); // keep looking inside house
    }
  });
  createRoom();
  createTable();


});




// function applyShake(time) {
//   if (simulation.state === "shaking" && simulation.shakeIntensity > 0) {
//     const shake = simulation.shakeIntensity * 0.05;

//     house.position.x = Math.sin(time * 20) * shake;
//     house.position.z = Math.cos(time * 25) * shake;

//     floor.position.x = Math.sin(time * 18) * shake * 0.5;
//     floor.position.z = Math.cos(time * 22) * shake * 0.5;

//     camera.position.x += (Math.random() - 0.5) * shake * 0.2;
//     camera.position.y += (Math.random() - 0.5) * shake * 0.2;
//   } else {
//     house.position.set(0, 0, 0);
//     ground.position.set(0, 0, 0);   
//   }
// }

function applyShake() {
  if (simulation.shakeIntensity > 0) {
    const time = performance.now() * 0.01;
    const shake = simulation.shakeIntensity * 0.05;

    house.position.x = Math.sin(time * 20) * shake;
    house.position.z = Math.cos(time * 25) * shake;
    floor.position.x = Math.sin(time * 18) * shake ;
    floor.position.z = Math.cos(time * 22) * shake;
    camera.position.x += Math.sin(time * 30) * shake * 0.2;
    camera.position.y += Math.cos(time * 30) * shake * 0.2;
  }
}

let room, table;

function createRoom() {
  room = new THREE.Group();
  const wallMaterial = new THREE.MeshStandardMaterial({ 
         map:wallcolortexture,
        aoMap:wallarmtexture,
        roughnessMap:wallarmtexture,
        metalnessMap:wallarmtexture,
        normalMap:wallnormaltexture
  });

  const backWall = new THREE.Mesh(new THREE.BoxGeometry(3.7,2.2,0.2), wallMaterial);
  backWall.position.set(0, 1.2, -1);

  const leftWall = new THREE.Mesh(new THREE.BoxGeometry(3.7,2.2,0.2), wallMaterial);
  leftWall.position.set(-1, 1.2, 0);
  leftWall.rotation.y = Math.PI * 0.5
  const rightWall = new THREE.Mesh(new THREE.BoxGeometry(3.7,2.2,0.2), wallMaterial);
  rightWall.position.set(1, 1.2, 0);
  rightWall.rotation.y = Math.PI * 0.5

  room.add( backWall, leftWall, rightWall);
  scene.add(room);
}

function createTable() {
  table = new THREE.Group();
  const mat = new THREE.MeshStandardMaterial({ color: 0x8B4513 });

  const top = new THREE.Mesh(new THREE.BoxGeometry(1.45, 0.13, 0.65), mat);
  top.position.y = 1;
  table.add(top);

  const legGeo = new THREE.BoxGeometry(0.1, 1, 0.1);
  const legs = [
    [-0.6, 0.5, 0.2],
    [0.6, 0.5, 0.2],
    [-0.6, 0.5, -0.2],
    [0.6, 0.5, -0.2,]
];

  legs.forEach(([x, y, z]) => {
    const leg = new THREE.Mesh(legGeo, mat);
    leg.position.set(x, y, z);
    table.add(leg);
  });

  scene.add(table);
  table.position.set(0, 0, 0);
}

// quiz btn


safeChoiceBtn.addEventListener("click", () => {
  
  quizScreen.classList.add("hidden");
  resultScreen.classList.add("show");
  
  resultMessage.textContent = "✅ Correct! Hiding under the table is safest.";
  outcome.textContent = "Hiding under a sturdy table protects you from falling objects. ✅ Next step: Hold on and stay put until the shaking stops."
  resultMessage.className = "success";
  
   gsap.to(camera.position, { x: 0, y: 0.8, z: 0, duration: 2, ease: "power2.inOut" });
   gsap.from("#result-screen > div",{
        x:-300,
        opacity:0,
        duration:0.5,
        stagger:0.5,
        delay:1
    })
    gsap.to(simulation, { shakeIntensity: 0, duration: 2 });


});

riskyChoiceBtn.addEventListener("click", () => {
  quizScreen.classList.add("hidden");
  resultScreen.classList.add("show");
  resultMessage.textContent = "⚠️ Wrong! Running outside is dangerous.";
  outcome.textContent="Running outside during shaking is unsafe as debris and glass may fall. ❌ Next step: Learn to Drop, Cover, and Hold On indoors.";
  resultMessage.className = "failure";

  gsap.to(camera.position, { x: 0, y: 1.5, z: 8, duration: 2, ease: "power2.inOut" });
  gsap.from("#result-screen > div",{
        x:-300,
        opacity:0,
        duration:0.5,
        stagger:0.5,
        delay:1
    })
   gsap.to(simulation, { shakeIntensity: 2, duration: 1, onComplete: () => {
    gsap.to(simulation, { shakeIntensity: 0, duration: 3 });
      }});
});



/**
 * Animate
 */
const timer = new Timer()

const tick = () =>
{
    // Timer
    timer.update()
    const elapsedTime = timer.getElapsed()

    

    // Update controls
    controls.update()

    // Render
    renderer.render(scene, camera)

    // Call tick again on the next frame
    window.requestAnimationFrame(tick)

   if (
    Math.abs(camera.position.x - 0) < 0.1 &&
    Math.abs(camera.position.y - 1.5) < 0.1 &&
    Math.abs(camera.position.z - 1.8) < 0.1
    ) {
       quizScreen.style.display = "block";  // show text
    } else {
       quizScreen.style.display = "none";   // hide text
   }

   applyShake();
}

tick()